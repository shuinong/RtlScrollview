//
//  SceneDelegate.h
//  ScrRtlView
//
//  Created by elegen on 2024/5/7.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

