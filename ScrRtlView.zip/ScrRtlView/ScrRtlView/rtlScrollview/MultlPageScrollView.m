//
//  MutilPageScrollView.m
//  Ayome
//
//  Created by elegen on 2024/3/6.
//
//#import <Masonry/Masonry.h>
#import "Masonry.h"
#import "MultlPageScrollView.h"

#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)

@interface MultlPageScrollView()<UIScrollViewDelegate>

@property(nonatomic, copy) NSArray *vArr;
@property(nonatomic, assign) NSInteger idxCur;
@end

@implementation MultlPageScrollView

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
       // [self createUIs];
        self.idxDef = 0;
        self.idxCur = self.idxDef;
    }
    return self;
}

-(BOOL)isRtlEnv{
    BOOL bRet = NO;
    NSLocale *currentLocale = [NSLocale currentLocale];
    NSString *languageCode = [currentLocale objectForKey:NSLocaleLanguageCode];
     
    if ([NSLocale characterDirectionForLanguage:[currentLocale objectForKey:NSLocaleLanguageCode]] == NSLocaleLanguageDirectionRightToLeft) {
        bRet = YES;
    }
    return bRet;
}

- (void)reverse:(NSMutableArray*)arr {
    NSUInteger count = arr.count;
    int mid = floor(count / 2.0);
    for (NSUInteger i = 0; i < mid; i++) {
        [arr exchangeObjectAtIndex:i withObjectAtIndex:(count - (i + 1))];
    }
}

-(void)createUIs:(NSArray *)viewArr{
    
    if([self isRtlEnv]){
        NSMutableArray *marr =  [NSMutableArray arrayWithArray:viewArr];
        [self reverse:marr];
        self.vArr = marr;
    }
    else {
        self.vArr = viewArr;
    }
    self.scrView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    self.scrView.showsVerticalScrollIndicator = NO;
    self.scrView.showsHorizontalScrollIndicator = NO;
    [self.scrView setPagingEnabled:YES];
    self.scrView.delegate = self;
    self.scrView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    [self addSubview:self.scrView];
    
    if([self isRtlEnv]){
        self.scrView.semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
    }
       
    [self.scrView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self);
        make.trailing.equalTo(self);
        make.top.equalTo(self);
        make.bottom.equalTo(self);
    }];
       
    
    CGFloat xOffset = 0;
    
    [self.scrView setContentSize:CGSizeMake(self.vArr.count*SCREEN_WIDTH, 0)];
    
    for(int idx = 0; idx < self.vArr.count; idx++){
  
        UIView *vTmp = [self.vArr objectAtIndex:idx];
        if([vTmp isKindOfClass:UIView.class]){
            [self.scrView addSubview:vTmp];
            
            [vTmp mas_makeConstraints:^(MASConstraintMaker *make) {
                make.leading.equalTo(self.scrView).offset(xOffset);
                make.top.equalTo(self.scrView);
                make.width.equalTo(@(SCREEN_WIDTH));
                make.height.equalTo(self.scrView);
            }];
        }
     
        xOffset += SCREEN_WIDTH;
        
    }
    
  //  [self setButtonSelected:0];
    [self scrollToIndex:self.idxDef];
}

-(void)createUIs:(NSArray *)ctrllerArr HostVc:(UIViewController *)hostVc{
    
    if([self isRtlEnv]){
        NSMutableArray *marr =  [NSMutableArray arrayWithArray:ctrllerArr];
        //[marr reverse];
        [self reverse:marr];
        self.vArr = marr;
    }
    else {
        self.vArr = ctrllerArr;
    }
    
    self.scrView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    self.scrView.showsVerticalScrollIndicator = NO;
    self.scrView.showsHorizontalScrollIndicator = NO;
    [self.scrView setPagingEnabled:YES];
    self.scrView.delegate = self;
    [self addSubview:self.scrView];
    
    if([self isRtlEnv]){
        self.scrView.semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
    }
       
    [self.scrView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self);
        make.trailing.equalTo(self);
        make.top.equalTo(self);
        make.bottom.equalTo(self);
    }];
           
    CGFloat xOffset = 0;
    [self.scrView setContentSize:CGSizeMake(self.vArr.count*SCREEN_WIDTH, 0)];
    if(hostVc){
        for(int idx = 0; idx < self.vArr.count; idx++){
            
            UIViewController *vcTmp = [self.vArr objectAtIndex:idx];
            if([vcTmp isKindOfClass:UIViewController.class]){
                [hostVc addChildViewController:vcTmp];
                [self.scrView addSubview:vcTmp.view];
                
                [vcTmp.view mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.leading.equalTo(self.scrView).offset(xOffset);
                    make.top.equalTo(self.scrView);
                    make.width.equalTo(@(SCREEN_WIDTH));
                    make.height.equalTo(self.scrView);
                }];
            }
            xOffset += SCREEN_WIDTH;
        }
    }
    
  //  [self setButtonSelected:0];
    [self scrollToIndex:self.idxDef];
    
}

-(void)scrollToIndex:(NSInteger)idx{
    self.idxCur = idx;
    CGFloat offsetX = 0;
    offsetX = idx * SCREEN_WIDTH;
    if([self isRtlEnv]){
        offsetX = self.scrView.contentSize.width - (idx + 1 )* SCREEN_WIDTH;
    }
    [self.scrView setContentOffset:CGPointMake(offsetX, 0) animated:YES];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if (scrollView == self.scrView) {
        CGFloat offsetX = scrollView.contentOffset.x;

        CGFloat index = offsetX / SCREEN_WIDTH;
       
        if (index == ceilf(index)) {
            NSInteger idxPage = self.vArr.count;
            
            if([self isRtlEnv]){
                idxPage = (NSInteger)(idxPage -  index - 1);
            }
            else {
                idxPage = index;
            }
            self.idxCur = idxPage;
            if(self.onScrolledAtIdx){
                self.onScrolledAtIdx(idxPage);
            }
        }
    }
}


@end
