//
//  MutilPageScrollView.h
//  Ayome
//
//  Created by elegen on 2024/3/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef void (^ON_SCROLLED_AT)(NSInteger idx);
@interface MultlPageScrollView : UIView

@property(nonatomic, strong) UIScrollView *scrView;
@property(nonatomic, assign) NSInteger idxDef;//默认显示的页面
@property(nonatomic, copy) ON_SCROLLED_AT onScrolledAtIdx;
-(void)scrollToIndex:(NSInteger)idx;
-(void)createUIs:(NSArray *)viewArr;
-(void)createUIs:(NSArray *)ctrllerArr HostVc:(UIViewController*)hostVc;
@end

NS_ASSUME_NONNULL_END
