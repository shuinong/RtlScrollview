//
//  ViewController.m
//  ScrRtlView
//
//  Created by elegen on 2024/5/7.
//

#import "ViewController.h"
#import "Masonry.h"
#import "SubVC.h"
#import "MultlPageScrollView.h"

#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)

@interface ViewController ()
@property(nonatomic, strong) NSMutableArray *titleBtnArr;
@property(nonatomic, strong) MultlPageScrollView *scrPageView;
@property(nonatomic, assign) NSInteger  curViewIdx;//当前是哪个页面
@property (strong, nonatomic) NSMutableArray<SubVC*>  *contentViewArr;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.curViewIdx = 0;
    [self createVCs];
    
}

-(BOOL)isRtlEnv{
    BOOL bRet = NO;
    NSLocale *currentLocale = [NSLocale currentLocale];
    NSString *languageCode = [currentLocale objectForKey:NSLocaleLanguageCode];
     
    if ([NSLocale characterDirectionForLanguage:[currentLocale objectForKey:NSLocaleLanguageCode]] == NSLocaleLanguageDirectionRightToLeft) {
        bRet = YES;
    }
    
    return bRet;
}

-(NSMutableArray*)contentViewArr{
    if(!_contentViewArr){
        _contentViewArr = [[NSMutableArray alloc] init];
    }
    return _contentViewArr;
}

-(NSMutableArray*)titleBtnArr{
    if(!_titleBtnArr){
        _titleBtnArr = [[NSMutableArray alloc] init];
    }
    return _titleBtnArr;
}


-(void)createVCs{
    NSArray<NSString*> *titleArr = @[@"First", @"Second", @"Third"];

    CGFloat offsetX = 16;

    CGFloat widthBtn = 80;
    for(int idx = 0; idx < titleArr.count; idx++){
       
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, widthBtn, 30)];
        btn.titleLabel.font = [UIFont systemFontOfSize:12];
        [btn setTitle:titleArr[idx] forState:UIControlStateNormal];
        [btn setTitleColor:UIColor.blueColor forState:UIControlStateNormal];
        btn.layer.borderWidth = 0.5;
        btn.layer.borderColor = UIColor.grayColor.CGColor;
        [self.view addSubview:btn];
        
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(@(widthBtn));
            make.leading.equalTo(@(offsetX));
            make.top.equalTo(@100);
            make.height.equalTo(@30);
        }];
                
        offsetX += widthBtn;
        [self.titleBtnArr addObject:btn];

        [btn addTarget:self action:@selector(onClickButtonTitle:) forControlEvents:UIControlEventTouchUpInside];
                
    }
    
    
    
    self.scrPageView = [[MultlPageScrollView alloc] initWithFrame:CGRectMake(0, 130, SCREEN_WIDTH,  SCREEN_HEIGHT - 130)];

//    self.scrPageView.scrView.delegate = self;
    self.scrPageView.scrView.backgroundColor = UIColor.whiteColor;
    if( [self isRtlEnv] ){
        self.scrPageView.scrView.semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
    }
    [self.view addSubview:self.scrPageView];
    [self.scrPageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.view);
        make.width.equalTo(@(SCREEN_WIDTH));
        make.top.equalTo(@130);
        make.bottom.equalTo(self.view).offset(0);
    }];
   
    self.contentViewArr = [[NSMutableArray alloc] init];
    
    for(int idx = 0; idx < titleArr.count; idx++){
        SubVC *vContent = [[SubVC alloc] init];
        vContent.vcType = idx + 1;
        [self.contentViewArr addObject:vContent];
    }
    [self.scrPageView createUIs:self.contentViewArr HostVc:self];
    self.scrPageView.scrView.showsVerticalScrollIndicator = NO;
    self.scrPageView.scrView.showsHorizontalScrollIndicator = NO;
    [self.scrPageView.scrView setPagingEnabled:YES];
    self.scrPageView.scrView.scrollEnabled =  YES;
    __weak typeof(self) weakSelf = self;
    self.scrPageView.onScrolledAtIdx = ^(NSInteger idx) {
        [weakSelf setButtonSelected:idx];
    };
    
    self.curViewIdx = 0;
    [self setButtonSelected:self.curViewIdx];
}

-(void)onClickButtonTitle:(UIButton*)btn{
    if(btn){
        for(int idx = 0; idx < self.titleBtnArr.count; idx++){
            UIButton *btnT = [self.titleBtnArr objectAtIndex:idx];
            if(btn == btnT){

                [self setButtonSelected:idx];
                [self.scrPageView scrollToIndex:idx];
                
                break;
            }
        }
    }
}



-(void)setButtonSelected:(NSInteger)btnIdx{
    self.curViewIdx = btnIdx;
   UIColor *selColor = [UIColor colorWithRed:((float) 70 / 255.0f)
                           green:((float) 90 / 255.0f)
                            blue:((float) 66 / 255.0f)
                           alpha:0.25];
    for(int idx = 0; idx < self.titleBtnArr.count; idx++){
        UIButton *btn = [self.titleBtnArr objectAtIndex:idx];
        if(btn && [btn isKindOfClass:UIButton.class]){
            if(btnIdx == idx){
                [btn setBackgroundColor:selColor];
                [btn setTitleColor:UIColor.blueColor forState:UIControlStateNormal];
            }
            else {
                [btn setBackgroundColor:UIColor.clearColor];
                [btn setTitleColor:UIColor.blackColor forState:UIControlStateNormal];
            }
        }
    }
}

@end
