//
//  SubVC.h
//  RtlScrollview
//
//  Created by elegen on 2024/5/7.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SubVC : UIViewController
@property(nonatomic, assign) NSInteger vcType;
@end

NS_ASSUME_NONNULL_END
