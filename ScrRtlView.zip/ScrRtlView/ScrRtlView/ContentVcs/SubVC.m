//
//  SubVC.m
//  RtlScrollview
//
//  Created by elegen on 2024/5/7.
//

#import "SubVC.h"

@interface SubVC ()

@end

@implementation SubVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if(self.vcType == 1){
        self.view.backgroundColor = UIColor.redColor;
    }
    else if(self.vcType == 2){
        self.view.backgroundColor = UIColor.grayColor;
        
    }
    else {
        self.view.backgroundColor = UIColor.greenColor;
    }
}



@end
